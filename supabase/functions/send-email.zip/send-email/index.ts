import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { SmtpClient } from "https://deno.land/x/smtp@v0.7.0/mod.ts";
import { corsHeaders } from "../_shared/cors.ts";

// Detalhes do Servidor SMTP (virão dos segredos do Supabase)
const SMTP_HOST = Deno.env.get("SMTP_HOST")!;
const SMTP_PORT = parseInt(Deno.env.get("SMTP_PORT")!, 10);
const SMTP_USER = Deno.env.get("SMTP_USER")!;
const SMTP_PASSWORD = Deno.env.get("SMTP_PASSWORD")!;

serve(async (req) => {
    // Tratar requisição pre-flight do CORS
    if (req.method === 'OPTIONS') {
        return new Response('ok', { headers: corsHeaders });
    }

    try {
        const { to, subject, html } = await req.json();

        if (!to || !subject || !html) {
            return new Response(JSON.stringify({ error: 'Faltando parâmetros: to, subject, html' }), {
                status: 400,
                headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            });
        }

        const client = new SmtpClient();

        await client.connectTLS({
            hostname: SMTP_HOST,
            port: SMTP_PORT,
            username: SMTP_USER,
            password: SMTP_PASSWORD,
        });

        await client.send({
            from: `"CGB Energia Recrutamento" <${SMTP_USER}>`,
            to,
            subject,
            content: "Esta é uma mensagem em texto plano.", // Fallback
            html,
        });

        await client.close();

        return new Response(JSON.stringify({ message: 'E-mail enviado com sucesso!' }), {
            status: 200,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });

    } catch (error) {
        console.error('Erro ao enviar e-mail:', error);
        return new Response(JSON.stringify({ error: error.message }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
    }
}); 